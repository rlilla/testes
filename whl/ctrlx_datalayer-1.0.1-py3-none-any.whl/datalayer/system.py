import datalayer
import datalayer.clib_system
from datalayer.factory import Factory
from datalayer.converter import Converter


class System:
    """
        Datalayer System Instance

        Hint: see python context manager for instance handling
    """

    def __init__(self, ipc_path: str):
        """
        generate System
        """
        b_ipc_path = ipc_path.encode('utf-8')
        self.c_system = datalayer.clib.libcomm_datalayer.DLR_systemCreate(
            b_ipc_path)
        self.closed = False

    def __enter__(self):
        """
        use the python context manager
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        use the python context manager
        """
        self.close()

    def close(self):
        """
        closes the system instance
        """
        if self.closed:
            return
        self.closed = True
        self.stop(True)
        datalayer.clib.libcomm_datalayer.DLR_systemDelete(self.c_system)

    def start(self, bo_start_broker: bool):
        """
        Start the datalayer (broker)
        """
        datalayer.clib.libcomm_datalayer.DLR_systemStart(
            self.c_system, bo_start_broker)

    def stop(self, bo_force_provider_stop: bool) -> bool:
        """
        Stop the datalayer (broker)

        returns false if there is a client or provider active
        """
        return datalayer.clib.libcomm_datalayer.DLR_systemStop(self.c_system, bo_force_provider_stop)

    def factory(self) -> Factory:
        """
        Returns the factory to create clients and provider for the datalayer

        :returns: <Factory>
        """
        c_factory = datalayer.clib.libcomm_datalayer.DLR_systemFactory(
            self.c_system)
        return Factory(c_factory)

    def json_converter(self) -> Converter:
        """
        Returns converter between JSON and Variant

        :returns: Converter between JSON and Variant
        """
        c_converter = datalayer.clib.libcomm_datalayer.DLR_systemJsonConverter(
            self.c_system)
        return Converter(c_converter)

    def set_bfbs_path(self, path):
        """
        Sets the base path to bfbs files

        @param[in] path    Base path to bfbs files
        """
        b_path = path.encode('utf-8')
        datalayer.clib.libcomm_datalayer.DLR_systemSetBfbsPath(
            self.c_system, b_path)
