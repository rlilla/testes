import datalayer
from datalayer.variant import Result, Variant
from datalayer.provider_node import ProviderNode
from datalayer.clib_provider import C_DLR_PROVIDER


class Provider:
    """
        Provider interface to manage provider nodes

        Hint: see python context manager for instance handling
    """

    def __init__(self, c_provider: C_DLR_PROVIDER):
        """
        generate Provider
        """
        self.c_provider: C_DLR_PROVIDER = c_provider
        self.closed = False

    def __enter__(self):
        """
        use the python context manager
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        use the python context manager
        """
        self.close()

    def close(self):
        """
        closes the provider instance
        """
        if self.closed:
            return
        self.closed = True
        datalayer.clib.libcomm_datalayer.DLR_providerStop(self.c_provider)
        datalayer.clib.libcomm_datalayer.DLR_providerDelete(self.c_provider)

    def register_type(self, address: str, pathname: str) -> Result:
        """
        Register a type to the datalayer

        @param[in]  address   Address of the node to register (no wildcards allowed)

        @param[in]  pathname  Path to flatbuffer bfbs

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        b_pathname = pathname.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerRegisterType(self.c_provider, b_address, b_pathname))

    def unregister_type(self, address: str) -> Result:
        """
        Unregister a type from the datalayer

        @param[in]  address   Address of the node to register (wildcards allowed)

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerUnregisterType(self.c_provider, b_address))

    def register_node(self, address: str, node: ProviderNode) -> Result:
        """
        Register a node to the datalayer

        @param[in]  address   Address of the node to register (wildcards allowed)

        @param[in]  node      Node to register

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerRegisterNode(self.c_provider, b_address, node.c_provider_node))

    def unregister_node(self, address: str) -> Result:
        """
        Unregister a node from the datalayer

        @param[in]  address   Address of the node to register (wildcards allowed)

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerUnregisterNode(self.c_provider, b_address))

    def set_timeout_node(self, node: ProviderNode, timeout_ms: int) -> Result:
        """
        Set timeout for a node for asynchron requests (default value is 1000ms)

        @param[in]  node      Node to set timeout for

        @param[in]  timeoutMS Timeout in milliseconds for this node

        :returns: <Result>, status of function call
        """
        if node is None:
            return Result.FAILED
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerSetTimeoutNode(self.c_provider, node.c_provider_node, timeout_ms))

    def start(self) -> Result:
        """
        Start the provider

        :returns: <Result>, status of function call
        """
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerStart(self.c_provider))

    def stop(self) -> Result:
        """
        Stop the provider

        :returns: <Result>, status of function call
        """
        return Result(datalayer.clib.libcomm_datalayer.DLR_providerStop(self.c_provider))

    def is_connected(self) -> bool:
        """
        returns whether provider is connected

        :returns: status of connection
        """
        return datalayer.clib.libcomm_datalayer.DLR_providerIsConnected(self.c_provider)

    def get_token(self) -> Variant:
        """        
        return the current token of the current request

        you can call this function during your onRead, onWrite, ... methods of

        your ProviderNodes.

        if there is no current request the method return an empty token

        :returns: <Variant> current token
        """
        return Variant(datalayer.clib.libcomm_datalayer.DLR_providerGetToken(self.c_provider))
