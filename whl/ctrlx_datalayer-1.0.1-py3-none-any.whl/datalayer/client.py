import ctypes
import typing
from enum import Enum
import datalayer.clib
from datalayer.clib import userData_c_void_p
from datalayer.variant import Variant, Result, VariantRef
from datalayer.clib_client import C_DLR_CLIENT, C_DLR_CLIENT_RESPONSE, C_NotifyItem

ResponseCallback = typing.Callable[[
    Result, typing.Optional[Variant], datalayer.clib.userData_c_void_p], None]

ResponseNotifyCallback = typing.Callable[[
    Result, ctypes.POINTER(C_NotifyItem), ctypes.c_uint32, datalayer.clib.userData_c_void_p], None]


class _CallbackPtr:
    """
        Callback wrapper
    """

    def __init__(self):
        """
        init _CallbackPtr
        """
        self.ptr: typing.Optional[ctypes._CFuncPtr] = None

    def set_ptr(self, ptr):
        """
        setter CallbackPtr
        """
        self.ptr = ptr


class TimeoutSetting(Enum):
    """
    Settings of different timeout values
    """
    IDLE = 0
    PING = 1
    Reconnect = 2


class Client:
    """
    Client interface for accessing data from the system

    Hint: see python context manager for instance handling
    """

    def __init__(self, c_client: C_DLR_CLIENT):
        """
        @param[in]  client    Reference to the client
        """
        self.closed = False
        self.c_client: C_DLR_CLIENT = c_client
        self.b_token = None
        self.__ptrs: typing.List[_CallbackPtr] = []

    def __enter__(self):
        """
        use the python context manager
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        use the python context manager
        """
        self.close()

    def close(self):
        """
        closes the client instance
        """
        if self.closed:
            return
        self.closed = True
        datalayer.clib.libcomm_datalayer.DLR_clientDelete(self.c_client)
        self.__ptrs.clear()

    def __create_callback(self, cb: ResponseCallback):
        """
        callback management
        """
        cb_ptr = _CallbackPtr()
        self.__ptrs.append(cb_ptr)

        def _cb(c_result: datalayer.clib.C_DLR_RESULT, c_data: ctypes.c_void_p, c_userdata: ctypes.c_void_p):
            """
            datalayer calls this function
            """
            if c_data is None:
                cb(Result(c_result), None, c_userdata)
            else:
                data = VariantRef(c_data)
                cb(Result(c_result), data, c_userdata)
            cb_ptr.ptr = None  # remove cyclic dependency
            self.__ptrs.remove(cb_ptr)

        cb_ptr.set_ptr(C_DLR_CLIENT_RESPONSE(_cb))
        return cb_ptr.ptr

    def _test_callback(self, cb: ResponseCallback):
        """
            internal use
        """
        return self.__create_callback(cb)

    def set_timeout(self, timeout: TimeoutSetting, value: int) -> Result:
        """
        Set client timeout value

        @param[in]  client    Reference to the client

        @param[in]  timeout   Timeout to set (see DLR_TIMEOUT_SETTING)

        @param[in]  value     Value to set

        :returns: <Result>, status of function call
        """
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientSetTimeout(self.c_client, timeout.value, value))

    def is_connected(self) -> bool:
        """
        returns whether provider is connected

        :returns: [bool] status of connection
        """
        return datalayer.clib.libcomm_datalayer.DLR_clientIsConnected(self.c_client)

    def set_auth_token(self, token: str):
        """
        Set persistent security access token for authentication as JWT payload

        @param[in]  token  Security access &token for authentication        
        """
        if token is None:
            raise TypeError('token is invalid')
        self.b_token = token.encode('utf-8')
        datalayer.clib.libcomm_datalayer.DLR_clientSetAuthToken(
            self.c_client, self.b_token)

    def get_auth_token(self) -> str:
        """

        returns persistent security access token for authentication

        :returns: [str] security access token for authentication
        """
        token = datalayer.clib.libcomm_datalayer.DLR_clientGetAuthToken(
            self.c_client)
        self.b_token = token
        return token.decode('utf-8')

    def ping_sync(self) -> Result:
        """
        Ping the next hop. This function is synchronous: It will wait for the answer.

        :returns: <Result> status of function call
        """
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientPingSync(self.c_client))

    def create_sync(self, address: str, data: Variant):
        """
        Create an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to create object in

        @param[in]  variant      Data of the object 

        :returns: tuple  (Result, Variant)
        :rtype: <Result>, status of function call
        :rtype: <Variant>, variant result of write
        """
        b_address = address.encode('utf-8')
        result = Result(datalayer.clib.libcomm_datalayer.DLR_clientCreateSync(
            self.c_client, b_address, data.c_variant, self.b_token))
        return result, data

    def remove_sync(self, address: str) -> Result:
        """
        Remove an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to remove

        :returns: <Result> status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientRemoveSync(self.c_client, b_address, self.b_token))

    def browse_sync(self, address: str):
        """
        Browse an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to browse

        :returns: tuple  (Result, Variant)
        :rtype: <Result>, status of function call, 
        :rtype: <Variant>, Children of the node. Data will be provided as Variant array of strings.
        """
        b_address = address.encode('utf-8')
        data = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_clientBrowseSync(
            self.c_client, b_address, data.c_variant, self.b_token))
        return result, data

    def read_sync(self, address: str):
        """
        Read an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to read

        :returns: tuple  (Result, Variant)
            :rtype: <Result>, status of function call, 
            :rtype: <Variant>, Data of the node
        """
        b_address = address.encode('utf-8')
        data = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_clientReadSync(
            self.c_client, b_address, data.c_variant, self.b_token))
        return result, data

    def write_sync(self, address: str, data: Variant):
        """
        Write an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to write

        @param[in] variant New data of the node

        :returns: tuple  (Result, Variant)
            :rtype: <Result>, status of function call, 
            :rtype: <Variant>, result of write
        """
        b_address = address.encode('utf-8')
        result = Result(datalayer.clib.libcomm_datalayer.DLR_clientWriteSync(
            self.c_client, b_address, data.c_variant, self.b_token))
        return result, data

    def metadata_sync(self, address: str):
        """
        Read metadata of an object. This function is synchronous: It will wait for the answer.

        @param[in]  address   Address of the node to read metadata of

        :returns: tuple  (Result, Variant)
        :rtype: <Result>, status of function call, 
        :rtype: <Variant>, Metadata of the node. Data will be provided as Variant flatbuffers with metadata.fbs data type.
        """
        b_address = address.encode('utf-8')
        data = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_clientMetadataSync(
            self.c_client, b_address, data.c_variant, self.b_token))
        return result, data

    def ping_async(self, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Ping the next hop. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result> status of function call
        """
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientPingASync(self.c_client, self.__create_callback(cb), userdata))

    def create_async(self, address: str, data: Variant, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Create an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  address   Address of the node to create object in

        @param[in]  data      Data of the object

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result> status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientCreateASync(self.c_client, b_address, data.c_variant, self.b_token, self.__create_callback(cb), userdata))

    def remove_async(self, address: str, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Remove an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  address   Address of the node to remove

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result> status of function call        
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientRemoveASync(self.c_client, b_address, self.b_token, self.__create_callback(cb), userdata))

    def browse_async(self, address: str, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Browse an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  address   Address of the node to browse

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result> status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientBrowseASync(self.c_client, b_address, self.b_token, self.__create_callback(cb), userdata))

    def read_async(self, address: str, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Read an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  address   Address of the node to read

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result>, status of function call        
        """
        b_address = address.encode('utf-8')
        data = Variant()
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientReadASync(self.c_client, b_address, data.c_variant, self.b_token, self.__create_callback(cb), userdata))

    def write_async(self, address: str, data: Variant, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Read metadata of an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  client    Reference to the client

        @param[in]  address   Address of the node to read metadata

        @param[in]  token     Security access token for authentication as JWT payload

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientWriteASync(self.c_client, b_address, data.c_variant, self.b_token, self.__create_callback(cb), userdata))

    def metadata_async(self, address: str, cb: ResponseCallback, userdata: userData_c_void_p = None) -> Result:
        """
        Read metadata of an object. This function is asynchronous. It will return immediately. Callback will be called if function call is finished.
        Result data may be provided in callback function.

        @param[in]  address   Address of the node to read metadata

        @param[in]  callback  Callback to call when function is finished

        @param[in]  userdata  User data - will be returned in callback as userdata. You can use this userdata to identify your request

        :returns: <Result>, status of function call
        """
        b_address = address.encode('utf-8')
        return Result(datalayer.clib.libcomm_datalayer.DLR_clientMetadataASync(self.c_client, b_address, self.b_token, self.__create_callback(cb), userdata))
