import datalayer
from datalayer.clib_factory import C_DLR_FACTORY
from datalayer.client import Client
from datalayer.provider import Provider


class Factory:
    """ Factory class """

    def __init__(self, c_factory: C_DLR_FACTORY):
        """
        generate Factory
        """
        self.c_factory = c_factory

    def create_client(self, remote: str) -> Client:
        """
        Creates a client for accessing data of the system

        @param[in] remote     Remote address of the data layer

        :returns: <Client>
        """
        b_remote = remote.encode('utf-8')
        c_client = datalayer.clib.libcomm_datalayer.DLR_factoryCreateClient(
            self.c_factory, b_remote)
        return Client(c_client)

    def create_provider(self, remote: str) -> Provider:
        """
        Creates a provider to provide data to the datalayer

        @param[in] remote     Remote address of the data layer

        :returns: <Provider>
        """
        b_remote = remote.encode('utf-8')
        c_provider = datalayer.clib.libcomm_datalayer.DLR_factoryCreateProvider(
            self.c_factory, b_remote)
        return Provider(c_provider)
