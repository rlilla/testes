import ctypes
import typing
import datalayer
from datalayer.variant import Result, Variant, VariantRef
from datalayer.clib import C_DLR_RESULT
from datalayer.clib_provider_node import C_DLR_PROVIDER_NODE_CALLBACKS, C_DLR_PROVIDER_NODE_FUNCTION_DATA, C_DLR_PROVIDER_NODE_FUNCTION, \
    userData_c_void_p, address_c_char_p, C_DLR_PROVIDER_NODE_CALLBACK, C_DLR_PROVIDER_NODE_CALLBACKDATA, C_DLR_VARIANT

NodeCallback = typing.Callable[[Result, typing.Optional[Variant]], None]
NodeFunction = typing.Callable[[userData_c_void_p, str, NodeCallback], None]
NodeFunctionData = typing.Callable[[
    userData_c_void_p, str, Variant, NodeCallback], None]


class _CallbackPtr:
    """
        _CallbackPtr helper
    """

    def __init__(self):
        """
        init _CallbackPtr
        """
        self.ptr: typing.Optional[ctypes._CFuncPtr] = None

    def set_ptr(self, ptr):
        """
        setter _CallbackPtr
        """
        self.ptr = ptr


class ProviderNodeCallbacks:
    """
        Provider Node callbacks  interface
    """

    def __init__(self, on_create: NodeFunctionData, on_remove: NodeFunction, on_browse: NodeFunction,
                 on_read: NodeFunctionData, on_write: NodeFunctionData, on_metadata: NodeFunction):
        """
        init ProviderNodeCallbacks
        """
        self.on_create = on_create
        self.on_remove = on_remove
        self.on_browse = on_browse
        self.on_read = on_read
        self.on_write = on_write
        self.on_metadata = on_metadata


class ProviderNode:
    """
        Provider node interface for providing data to the system

        Hint: see python context manager for instance handling
    """

    def __init__(self, cbs: ProviderNodeCallbacks, userdata: userData_c_void_p = None):
        """
        init ProviderNode
        """
        self.__ptrs: typing.List[_CallbackPtr] = []
        c_cbs = C_DLR_PROVIDER_NODE_CALLBACKS(
            userdata,
            self.__create_function_data(cbs.on_create),
            self.__create_function(cbs.on_remove),
            self.__create_function(cbs.on_browse),
            self.__create_function_data(cbs.on_read),
            self.__create_function_data(cbs.on_write),
            self.__create_function(cbs.on_metadata),
        )
        self.closed = False
        self.c_provider_node = datalayer.clib.libcomm_datalayer.DLR_providerNodeCreate(
            c_cbs)

    def __enter__(self):
        """
        use the python context manager
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        use the python context manager
        """
        self.close()

    def __del__(self):
        """
        __del__
        """
        self.close()

    def close(self):
        """
        closes the node instance
        """
        if self.closed:
            return
        self.closed = True
        datalayer.clib.libcomm_datalayer.DLR_providerNodeDelete(
            self.c_provider_node)
        self.__ptrs.clear()

    def __create_callback(self, c_cb: C_DLR_PROVIDER_NODE_CALLBACK, c_cbdata: C_DLR_PROVIDER_NODE_CALLBACKDATA) -> NodeCallback:
        """
        create callback
        """
        def cb(result: Result, data: typing.Optional[Variant]):
            """ cb """
            if data is None:
                c_cb(c_cbdata, result.value, None)
            else:
                c_cb(c_cbdata, result.value, data.c_variant)
        return cb

    def __create_function(self, func: NodeFunction):
        """
        create callback managment
        """
        cb_ptr = _CallbackPtr()
        self.__ptrs.append(cb_ptr)

        def _func(c_userdata: userData_c_void_p, c_address: address_c_char_p, c_cb: C_DLR_PROVIDER_NODE_CALLBACK, c_cbdata: C_DLR_PROVIDER_NODE_CALLBACKDATA) -> C_DLR_RESULT:
            """
            datalayer calls this function
            """
            address = c_address.decode('utf-8')
            cb = self.__create_callback(c_cb, c_cbdata)
            func(c_userdata, address, cb)
            return Result.OK.value
        cb_ptr.set_ptr(C_DLR_PROVIDER_NODE_FUNCTION(_func))
        return cb_ptr.ptr

    def __create_function_data(self, func: NodeFunctionData):
        """
        create callback managment
        """
        cb_ptr = _CallbackPtr()
        self.__ptrs.append(cb_ptr)

        def _func(c_userdata: userData_c_void_p, c_address: address_c_char_p, c_data: C_DLR_VARIANT, c_cb: C_DLR_PROVIDER_NODE_CALLBACK, c_cbdata: C_DLR_PROVIDER_NODE_CALLBACKDATA) -> C_DLR_RESULT:
            """
            datalayer calls this function
            """
            address = c_address.decode('utf-8')
            data = VariantRef(c_data)
            cb = self.__create_callback(c_cb, c_cbdata)
            func(c_userdata, address, data, cb)
            return Result.OK.value
        cb_ptr.set_ptr(C_DLR_PROVIDER_NODE_FUNCTION_DATA(_func))
        return cb_ptr.ptr

    def _test_function(self, func: NodeFunction):
        """
            internal use
        """
        return self.__create_function(func)

    def _test_function_data(self, func: NodeFunctionData):
        """
            internal use
        """
        return self.__create_function_data(func)
