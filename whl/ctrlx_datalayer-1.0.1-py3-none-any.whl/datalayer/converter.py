import ctypes
import datalayer
from enum import Enum
import datalayer.clib_converter
from datalayer.variant import Variant, Result

C_DLR_CONVERTER = ctypes.c_void_p


class C_DLR_SCHEMA(Enum):
    """
    Type of Converter 
    """
    METADATA = 0
    REFLECTION = 1
    MEMORY = 2
    MEMORY_MAP = 3
    TOKEN = 4
    PROBLEM = 5
    DIAGNOSIS = 6


class Converter:
    """
        Converter interface
    """

    def __init__(self, c_converter: C_DLR_CONVERTER):
        """
            generate converter
        """
        self.c_converter = c_converter

    def converter_generate_json_simple(self, data: Variant, indent_step: int):
        """
        This function generate a JSON string out of a Variant witch have a simple data type

        @param[in]  converter   A IFlatbufferJson* object which will do the actual conversion

        @param[in]  data        Variant which contains data with simple data type

        @param[in]  indentStep  Indentation length for json string

        :returns: tuple  (Result, Variant)
        :rtype: <Result>, status of function call, 
        :rtype: <Variant>, Generated JSON as Variant (string)
        """
        json = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_converterGenerateJsonSimple(
            self.c_converter, data.c_variant, json.c_variant, indent_step))
        return result, json

    def converter_generate_json_complex(self, data: Variant, ty: Variant, indent_step: int):
        """
        This function generate a JSON string out of a Variant with complex type (flatbuffers) and the metadata of this data

        @param[in]  converter   A IFlatbufferJson* object which will do the actual conversion

        @param[in]  data        Varaint which contains data of complex data type (flatbuffers) if data is empty (VariantType::UNKNOWN) type is converted to json schema

        @param[in]  type        Variant which contains type of data (Variant with flatbuffers BFBS)

        @param[in]  indentStep  Indentation length for json string

        :returns: tuple  (Result, Variant)
        :rtype: <Result>, status of function call, 
        :rtype: <Variant>, Generated JSON as Variant (string)
        """
        json = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_converterGenerateJsonComplex(
            self.c_converter, data.c_variant, ty.c_variant, json.c_variant, indent_step))
        return result, json

    def parse_json_simple(self, json: str):
        """
        This function generates a Variant out of a JSON string containing the (simple) data 

        @param[in]  converter   A IFlatbufferJson* object which will do the actual conversion

        @param[in]  json        Data of the Variant as a json string

        :returns: tuple  (Result, Variant, Variant)
        :rtype: <Result>,  status of function call, 
        :rtype: <Variant>, Variant which contains the data
        :rtype: <Variant>, Error as Variant (string)
        """
        b_json = json.encode('utf-8')
        data = Variant()
        err = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_converterParseJsonSimple(
            self.c_converter, b_json, data.c_variant, err.c_variant))
        return result, data, err

    def parse_json_complex(self, json: str, ty: Variant):
        """
        This function generates a Variant out of a JSON string containing the (complex) data

        @param[in]  converter   A IFlatbufferJson* object which will do the actual conversion

        @param[in]  json        Data of the Variant as a json string

        @param[in]  type        Variant which contains type of data (Variant with bfbs flatbuffer content)

        :returns: tuple  (Result, Variant, Variant)
        :rtype: <Result>,  status of function call, 
        :rtype: <Variant>, Variant which contains the data
        :rtype: <Variant>, Error as Variant (string)
        """
        b_json = json.encode('utf-8')
        data = Variant()
        err = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_converterParseJsonComplex(
            self.c_converter, b_json, ty.c_variant, data.c_variant, err.c_variant))
        return result, data, err

    def get_schema(self, schema: C_DLR_SCHEMA):
        """
        This function returns the type (schema)

        @param[in]  converter   A IFlatbufferJson* object which will retrieve the actual type

        @param[in]  schema      Requested schema

        :returns: tuple  (Result, Variant)
        :rtype: <Result>,  status of function call,
        :rtype: <Variant>, Variant which contains the type (schema)
        """
        data = Variant()
        result = Result(datalayer.clib.libcomm_datalayer.DLR_converterGetSchema(
            self.c_converter, schema.value, data.c_variant))
        return result, data
